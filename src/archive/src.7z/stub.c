
#include "stub.h"

static uint32_t g_One_ms_Timer_Tick_counter = 0;
static uint32_t counter = 0;
#define DONT_USE_SDK 1

  lpspi_state_t lpspi_1State;

  static void LPSPI_DRV_MasterCompleteTransfer(uint32_t instance);

status_t LPSPI_DRV_MasterInit_Stub(uint32_t instance, lpspi_state_t * lpspiState, const lpspi_master_config_t * spiConfig);
/**
 * @brief SPI driver
 **/
/*******************************************************************************
 * Variables
 ******************************************************************************/
#if 0
/*! @brief Table of base pointers for SPI instances. */
LPSPI_Type * g_lpspiBase[LPSPI_INSTANCE_COUNT] =  LPSPI_BASE_PTRS;

/*! @brief Table to save LPSPI IRQ enumeration numbers defined in the CMSIS header file. */
IRQn_Type g_lpspiIrqId[LPSPI_INSTANCE_COUNT] =  LPSPI_IRQS;

/* Pointer to runtime state structure.*/
lpspi_state_t * g_lpspiStatePtr[LPSPI_INSTANCE_COUNT] = FEATURE_LPSPI_STATE_STRUCTURES_NULL;
#endif

const SpiDriver spiDriver =
{
   spiInit,
   spiSetMode,
   spiSetBitrate,
   spiAssertCs,
   spiDeassertCs,
   spiTransfer
};
pin_settings_config_t spi_pin_mux[4U]= {
      {
        /* SIN pin */
        .base = PORTD,
        .pinPortIdx = 16,
        .pullConfig = PORT_INTERNAL_PULL_NOT_ENABLED,
        .passiveFilter = false,
        .driveSelect = PORT_LOW_DRIVE_STRENGTH,
        .mux = PORT_MUX_ALT4,
        .pinLock = false,
        .intConfig = PORT_DMA_INT_DISABLED,
        .clearIntFlag = false,
      },

      {
        /* SOUT pin */
        .base = PORTB,
        .pinPortIdx = 4,
        .pullConfig = PORT_INTERNAL_PULL_NOT_ENABLED,
        .passiveFilter = false,
        .driveSelect = PORT_LOW_DRIVE_STRENGTH,
        .mux = PORT_MUX_ALT3,
        .pinLock = false,
        .intConfig = PORT_DMA_INT_DISABLED,
        .clearIntFlag = false,
      },

      {
        /* SCK pin */
        .base = PORTD,
        .pinPortIdx = 15,
        .pullConfig = PORT_INTERNAL_PULL_NOT_ENABLED,
        .passiveFilter = false,
        .driveSelect = PORT_LOW_DRIVE_STRENGTH,
        .mux = PORT_MUX_ALT4,
        .pinLock = false,
        .intConfig = PORT_DMA_INT_DISABLED,
        .clearIntFlag = false,

      },

      {
        /* PCS0 pin */
        .base            = PORTB,
        .pinPortIdx      = 5,
        .pullConfig      = PORT_INTERNAL_PULL_NOT_ENABLED,
        .passiveFilter   = false,
        .driveSelect     = PORT_LOW_DRIVE_STRENGTH,
        .mux             = PORT_MUX_AS_GPIO,
        .pinLock         = false,
        .intConfig       = PORT_DMA_INT_DISABLED,
        .clearIntFlag    = false,
        .gpioBase        = PTB,
	    .direction       = GPIO_OUTPUT_DIRECTION,

      },
    };

#if DONT_USE_SDK

  const lpspi_master_config_t lpspi_0_MasterConfig0_stub = {
    .bitsPerSec =20000UL,
    .whichPcs = LPSPI_PCS0,
    .pcsPolarity = LPSPI_ACTIVE_LOW,
    .isPcsContinuous = false,
    .bitcount = 8U,
    .lpspiSrcClk = 8000000UL,
    .clkPhase = LPSPI_CLOCK_PHASE_2ND_EDGE,
    .clkPolarity = LPSPI_SCK_ACTIVE_LOW,
    .lsbFirst = false,
    .transferType = LPSPI_USING_INTERRUPTS,
    .rxDMAChannel = 0U,
    .txDMAChannel = 0U,
    .callback = NULL,
    .callbackParam = NULL
  };
#else
  const lpspi_master_config_t lpspi_0_MasterConfig0_stub = {
   .bitsPerSec = 1000000UL,
   .whichPcs = LPSPI_PCS0,
   .pcsPolarity = LPSPI_ACTIVE_LOW,
   .isPcsContinuous = false,
   .bitcount = 32U,
   .lpspiSrcClk = 8000000UL,
   .clkPhase = LPSPI_CLOCK_PHASE_2ND_EDGE,
   .clkPolarity = LPSPI_SCK_ACTIVE_LOW,
   .lsbFirst = false,
   .transferType = LPSPI_USING_INTERRUPTS,
   .rxDMAChannel = 0U,
   .txDMAChannel = 0U,
   .callback = NULL,
   .callbackParam = NULL
 };
#endif
  /* Define state structure for current SPI instance */


error_t spiInit(void)
{
  	/* Initialize LPSPI0 (Send)*/

     PINS_DRV_Init(4U, spi_pin_mux);
     PCC_SetPeripheralClockControl(PCC, LPSPI2_CLK, true, CLK_SRC_FIRC_DIV2, DIVIDE_BY_ONE, MULTIPLY_BY_ONE);

    /* Enable clock for PORTC */
    PCC_SetPeripheralClockControl(PCC, PORTC_CLK, true, CLK_SRC_OFF, DIVIDE_BY_ONE, MULTIPLY_BY_ONE);

	LPSPI_DRV_MasterInit_Stub(INST_LPSPI_1, &lpspi_1State, &lpspi_0_MasterConfig0_stub);

	//LPSPI_DRV_MasterInit(INST_LPSPI_1, &lpspi_1State, &lpspi_0_MasterConfig0_stub);

}

/*FUNCTION**********************************************************************
 *
 * Function Name : LPSPI_GetVersionId
 * Description   : Configures the LPSPI for master or slave.
 *
 * Note that the LPSPI module must first be disabled before configuring this.
 *
 *END**************************************************************************/
status_t LPSPI_SetMasterSlaveMode_Stub(LPSPI_Type * base, lpspi_master_slave_mode_t mode)
{
    base->CFGR1 = (base->CFGR1 & (~LPSPI_CFGR1_MASTER_MASK)) | ((uint32_t)mode << LPSPI_CFGR1_MASTER_SHIFT);
    return STATUS_SUCCESS;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : LPSPI_SetPcsPolarityMode
 * Description   : Configures the desired LPSPI PCS polarity.
 *
 * This function allows the user to configure the polarity of a particular PCS signal.
 * Note that the LPSPI module must first be disabled before configuring this.
 *
 *END**************************************************************************/
status_t LPSPI_SetPcsPolarityMode_Stub(LPSPI_Type * base, lpspi_which_pcs_t whichPcs,
                                            lpspi_signal_polarity_t pcsPolarity)
{
    uint32_t cfgr1Value = 0;

    /* Clear the PCS polarity bit */
    cfgr1Value = (base->CFGR1) & (~((uint32_t)1U << (LPSPI_CFGR1_PCSPOL_SHIFT + (uint32_t)whichPcs)));

    /* Configure the PCS polarity bit according to the pcsPolarity setting */
    cfgr1Value |= (uint32_t)pcsPolarity << (LPSPI_CFGR1_PCSPOL_SHIFT + (uint32_t)whichPcs);

    base->CFGR1 = cfgr1Value;

    return STATUS_SUCCESS;

}

/*!
 * @brief Manually configures a specific LPSPI delay parameter (module must be disabled to
 *        change the delay values).
 *
 * This function configures the:
 * SCK to PCS delay, or
 * PCS to SCK delay, or
 * Between transfer delay.
 *
 * These delay names are available in type lpspi_delay_type_t.
 *
 * The user passes which delay they want to configure along with the delay value.
 * This allows the user to directly set the delay values if they have
 * pre-calculated them or if they simply wish to manually increment the value.
 *
 * Note that the LPSPI module must first be disabled before configuring this.
 * Note that the LPSPI module must be configure for master mode before configuring this.
 *
 * @param base Module base pointer of type LPSPI_Type.
 * @param whichDelay The desired delay to configure, must be of type lpspi_delay_type_t
 * @param delay The 8-bit delay value 0x00 to 0xFF (255). The delay is equal to:
 *             -delay + 1 cycles of the LPSPI baud rate clock (SCK to PCS and PCS to SCK)
 *             -delay + 2 cycles of the LPSPI baud rate clock (Between transfer delay)
 * @return Either STATUS_SUCCESS, LPSPI_STATUS_OUT_OF_RANGE, or STATUS_ERROR if
 *         LPSPI is not disabled or if is not set for master mode.
 */
static inline status_t LPSPI_SetDelay_Stub(LPSPI_Type * base, lpspi_delay_type_t whichDelay, uint32_t delay)
{
    uint32_t ccrValue = 0;

    ccrValue = base->CCR & ~(0xFFUL << (uint32_t)whichDelay);
    ccrValue |= delay << (uint32_t)whichDelay;
    base->CCR = ccrValue;
    return STATUS_SUCCESS;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : LPSPI_SetBaudRate
 * Description   : Sets the LPSPI baud rate in bits per second.
 *
 * This function takes in the desired bitsPerSec (baud rate) and calculates the nearest
 * possible baud rate, and returns the calculated baud rate in bits-per-second. It requires
 * that the caller also provide the frequency of the module source clock (in Hertz).
 * Also note that the baud rate does not take into affect until the Transmit Control
 * Register (TCR) is programmed with the PRESCALE value. Hence, this function returns the
 * PRESCALE tcrPrescaleValue parameter for later programming in the TCR.  It is up to the
 * higher level peripheral driver to alert the user of an out of range baud rate input.
 * Note that the LPSPI module must first be disabled before configuring this.
 * Note that the LPSPI module must be configure for master mode before configuring this.
 *
 *END**************************************************************************/
uint32_t LPSPI_SetBaudRate_Stub(LPSPI_Type * base, uint32_t bitsPerSec,
                               uint32_t sourceClockInHz, uint32_t * tcrPrescaleValue)
{

    uint32_t bestFreq = 0xFFFFFFFFU;
    uint32_t bestScaler = 0U;
    uint32_t bestPrescaler = 0U;
    uint32_t freq1 = 0U;
    uint32_t freq2 = 0U;
    uint8_t scaler = 0U;
    uint8_t prescaler = 0U;
    uint32_t low, high;
    uint32_t tempBestFreq = 0U;
    uint32_t tempBestScaler = 0U;

    for (prescaler = 0; prescaler < 8U; prescaler++)
    {
        low = 0U;
        high = 256U;

        /* Implement golden section search algorithm */
        do
        {
            scaler = (uint8_t)((low + high) / 2U);
            freq1 = sourceClockInHz / (s_baudratePrescaler[prescaler] * (scaler + (uint32_t)2U));

            if (abs_dif(bitsPerSec, bestFreq) > abs_dif(bitsPerSec, freq1))
            {
                bestFreq = freq1;
            }
            if (freq1 < bitsPerSec)
            {
                high = scaler;
            }
            else
            {
                low = scaler;
            }
        }
        while((high - low) > 1U);

        /* Evaluate last 2 scaler values */
        freq1 = sourceClockInHz / (s_baudratePrescaler[prescaler] * (low + (uint32_t)2U));
        freq2 = sourceClockInHz / (s_baudratePrescaler[prescaler] * (high + (uint32_t)2U));

        if (abs_dif(bitsPerSec, freq1) > abs_dif(bitsPerSec, freq2))
        {
            tempBestFreq = freq2;
            tempBestScaler = high;
        }
        else
        {
            tempBestFreq = freq1;
            tempBestScaler = low;
        }

        if (abs_dif(bitsPerSec, bestFreq) >= abs_dif(bitsPerSec, tempBestFreq))
        {
            bestFreq = tempBestFreq;
            bestScaler = tempBestScaler;
            bestPrescaler = prescaler;
        }

        /* If current frequency is equal to target frequency  stop the search */
        if(bestFreq == bitsPerSec)
        {
            break;
        }
    }

    /* Add default values for delay between transfers, delay between sck to pcs and between pcs to sck. */
    (void)LPSPI_SetDelay_Stub(base, LPSPI_SCK_TO_PCS, bestScaler >> 2U);
    (void)LPSPI_SetDelay_Stub(base, LPSPI_PCS_TO_SCK, bestScaler >> 2U);
    (void)LPSPI_SetDelay_Stub(base, LPSPI_BETWEEN_TRANSFER, bestScaler >> 2U);

    /* Write the best baud rate scalar to the CCR.
     * Note, no need to check for error since we've already checked to make sure the module is
     * disabled and in master mode. Also, there is a limit on the maximum divider so we will not
     * exceed this.
     */
    (void)LPSPI_SetBaudRateDivisor(base, bestScaler);

    /* return the best prescaler value for user to use later */
    *tcrPrescaleValue = bestPrescaler;

    /* return the actual calculated baud rate */
    return bestFreq;
}

typedef struct uint1024_t
{
	uint8_t data[128];
}value;


/*FUNCTION**********************************************************************
 *
 * Function Name : LPSPI_DRV_MasterConfigureBus
 * Description   : Configures the LPSPI port physical parameters to access a device on the bus when
 *                 the LSPI instance is configured for interrupt operation.
 *
 * In this function, the term "spiConfig" is used to indicate the SPI device for which the LPSPI
 * master is communicating. This is an optional function as the spiConfig parameters are
 * normally configured in the initialization function or the transfer functions, where these various
 * functions would call the configure bus function.
 * The user can pass in a different spiConfig structure to the transfer function which contains
 * the parameters for the SPI bus to allow for communication to a different SPI device
 * (the transfer function then calls this function). However, the user also has the option to call
 * this function directly especially to get the calculated baud rate, at which point they may pass
 * in NULL for the spiConfig structure in the transfer function (assuming they have called this
 * configure bus function first).
 * Implements : LPSPI_DRV_MasterConfigureBus_Activity
 *
 *END**************************************************************************/
status_t LPSPI_DRV_MasterConfigureBus_Stub(uint32_t instance,
                                            const lpspi_master_config_t * spiConfig,
                                            uint32_t * calculatedBaudRate)
{
    DEV_ASSERT(instance < LPSPI_INSTANCE_COUNT);
    DEV_ASSERT(spiConfig != NULL);
    DEV_ASSERT(g_lpspiStatePtr[instance] != NULL);
    /* Instantiate local variable of type lpspi_state_t and point to global state */
    lpspi_state_t * lpspiState = g_lpspiStatePtr[instance];
    LPSPI_Type *base = g_lpspiBase[instance];
    uint32_t baudRate;

    /* The Transmit Command Register (TCR) Prescale value is calculated as part of the baud rate
       calculation. The value is stored in the run-time state structure for later programming
       in the TCR. */
    uint32_t tcrPrescaleValue;

    /* First, per the spec, we need to disable the LPSPI module before setting the delay */

    if (LPSPI_Disable(base) != STATUS_SUCCESS)
    {
        /* If error is returned, the LPSPI is busy */
        return STATUS_ERROR;
    }

    /* Check the bitcount to make sure it falls within the boundary conditions */
    if ((spiConfig->bitcount < 8U) || (spiConfig->bitcount > 4096U))
    {
        return STATUS_ERROR;
    }

    /* Configure internal state structure for LPSPI */
    lpspiState->bitsPerFrame = spiConfig->bitcount;
    lpspiState->lpspiSrcClk = (uint32_t) 8000000; // spiConfig->lpspiSrcClk;
    lpspiState->isPcsContinuous = spiConfig->isPcsContinuous;
    lpspiState->lsb = spiConfig->lsbFirst;
    /* Save transfer type DMA/Interrupt */
    lpspiState->transferType = spiConfig->transferType;
    /* Update transfer status */
    lpspiState->isTransferInProgress = false;
    lpspiState->isBlocking = false;
    /* Calculate the bytes/frame for lpspiState->bytesPerFrame. */
    lpspiState->bytesPerFrame = (uint16_t)((lpspiState->bitsPerFrame + 7U) / 8U);
    /* Due to DMA limitations frames of 3 bytes/frame will be internally handled as 4 bytes/frame. */
    if (lpspiState->bytesPerFrame == 3U)
    {
        lpspiState->bytesPerFrame = 4U;
    }
    /* Due to some limitations all frames bigger than 4 bytes/frame must be composed only from 4 bytes chunks. */
    if (lpspiState->bytesPerFrame > 4U)
    {
        lpspiState->bytesPerFrame = (((lpspiState->bytesPerFrame - 1U) / 4U) + 1U) * 4U;
    }
    /* Store DMA channel number used in transfer */
    lpspiState->rxDMAChannel = spiConfig->rxDMAChannel;
    lpspiState->txDMAChannel = spiConfig->txDMAChannel;
    /* Store callback */
    lpspiState->callback = spiConfig->callback;
    lpspiState->callbackParam = spiConfig->callbackParam;
    /* Configure the desired PCS polarity */
    (void)LPSPI_SetPcsPolarityMode_Stub(base, spiConfig->whichPcs, spiConfig->pcsPolarity);
    /* Set up the baud rate */
    baudRate = LPSPI_SetBaudRate(base, spiConfig->bitsPerSec, spiConfig->lpspiSrcClk, &tcrPrescaleValue);
    /* Enable sampling point delay */
    LPSPI_SetSamplingPoint(base, true);
    /* Now, re-enable the LPSPI module */
    LPSPI_Enable(base);
    /* If the baud rate return is "0", it means there was an error */
    if (baudRate == (uint32_t)0)
    {
        return STATUS_ERROR;
    }
    /* If the user wishes to know the calculated baud rate, then pass it back */
    if (calculatedBaudRate != NULL)
    {
        *calculatedBaudRate = baudRate;
    }
    /* Write the TCR for this transfer. */
    lpspi_tx_cmd_config_t txCmdCfg =
    {
        .frameSize = lpspiState->bitsPerFrame,
        .width = LPSPI_SINGLE_BIT_XFER,
        .txMask = false,
        .rxMask = false,
        .contCmd = false,
        .contTransfer = spiConfig->isPcsContinuous,
        .byteSwap = false,
        .lsbFirst = spiConfig->lsbFirst,
        .whichPcs = spiConfig->whichPcs,
        .preDiv = tcrPrescaleValue,
        .clkPhase = spiConfig->clkPhase,
        .clkPolarity = spiConfig->clkPolarity
    };
    LPSPI_SetTxCommandReg(base, &txCmdCfg);
    return STATUS_SUCCESS;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : LPSPI_SetPinConfigMode
 * Description   : Configures the LPSPI SDO/SDI pin configuration mode.
 *
 * This function configures the pin mode of the LPSPI.
 * For the SDI and SDO pins, the user can configure these pins as follows:
 *  SDI is used for input data and SDO for output data.
 *  SDO is used for input data and SDO for output data.
 *  SDI is used for input data and SDI for output data.
 *  SDO is used for input data and SDI for output data.
 *
 * The user has the option to configure the output data as:
 *  Output data retains last value when chip select is de-asserted (default setting).
 *  Output data is tristated when chip select is de-asserted.
 *
 * Finally, the user has the option to configure the PCS[3:2] pins as:
 *  Enabled for PCS operation (default setting).
 *  Disabled - this is need if the user wishes to configure the LPSPI mode for 4-bit transfers
 *             where these pins will be used as I/O data pins.
 *
 * Note that the LPSPI module must first be disabled before configuring this.
 *
 *END**************************************************************************/
status_t LPSPI_SetPinConfigMode_Stub(LPSPI_Type * base,
                                          lpspi_pin_config_t pinCfg,
                                          lpspi_data_out_config_t dataOutConfig,
                                          bool pcs3and2Enable)
{
    uint32_t cfgr1Value = 0;

    cfgr1Value = base->CFGR1 &
                 ~(LPSPI_CFGR1_PINCFG_MASK|LPSPI_CFGR1_OUTCFG_MASK|LPSPI_CFGR1_PCSCFG_MASK);

    cfgr1Value |= ((uint32_t)(pinCfg) << LPSPI_CFGR1_PINCFG_SHIFT) |
                  ((uint32_t)(dataOutConfig) << LPSPI_CFGR1_OUTCFG_SHIFT) |
                  ((uint32_t)(!pcs3and2Enable) << LPSPI_CFGR1_PCSCFG_SHIFT);  /* enable = 0 */

    base->CFGR1 = cfgr1Value;

	return STATUS_SUCCESS;
}

/*!
 * @brief Gets FIFO sizes of the LPSPI module.
 *
 * @ param base Module base pointer of type LPSPI_Type.
 * @ param fifoSize The FIFO size passed back to the user
 */
static inline void LPSPI_GetFifoSizes_Stub(const LPSPI_Type * base, uint8_t * fifoSize)
{
    if (fifoSize != NULL)
    {
        *fifoSize = (uint8_t)(1U << ((base->PARAM & LPSPI_PARAM_TXFIFO_MASK) >> LPSPI_PARAM_TXFIFO_SHIFT));
    }
}

/*FUNCTION**********************************************************************
 *
 * Function Name : LPSPI_DRV_MasterInit
 * Description   : Initializes a LPSPI instance for interrupt driven master mode operation.
 *
 * This function uses an interrupt-driven method for transferring data.
 * In this function, the term "spiConfig" is used to indicate the SPI device for which the LPSPI
 * master is communicating.
 * This function initializes the run-time state structure to track the ongoing
 * transfers, un-gates the clock to the LPSPI module, resets the LPSPI module,
 * configures the IRQ state structure, enables the module-level interrupt to the core, and
 * enables the LPSPI module.
 * Implements : LPSPI_DRV_MasterInit_Activity
 *
 *END**************************************************************************/
status_t LPSPI_DRV_MasterInit_Stub(uint32_t instance, lpspi_state_t * lpspiState,
                                    const lpspi_master_config_t * spiConfig)
{
    DEV_ASSERT(instance < LPSPI_INSTANCE_COUNT);
    DEV_ASSERT(lpspiState != NULL);
    DEV_ASSERT(spiConfig != NULL);
    LPSPI_Type *base = g_lpspiBase[instance];
    status_t errorCode = STATUS_SUCCESS;
    uint32_t baudRate;

    /* The Transmit Command Register (TCR) Prescale value is calculated as part of the baud rate
       calculation. The value is stored in the run-time state structure for later programming
       in the TCR. */
    uint32_t tcrPrescaleValue;

    /* Save runtime structure pointers so irq handler can point to the correct state structure */
    g_lpspiStatePtr[instance] = lpspiState;
    /* Reset the LPSPI registers to their default state */
    LPSPI_Init(base);
    /* Set for master mode */
    (void)LPSPI_SetMasterSlaveMode_Stub(base, LPSPI_MASTER);
    /* Set Pin configuration such that SDO=out and SDI=in */
    (void)LPSPI_SetPinConfigMode_Stub(base, LPSPI_SDI_IN_SDO_OUT, LPSPI_DATA_OUT_RETAINED, true);
    /* Calculate the FIFO size for the LPSPI */
    LPSPI_GetFifoSizes_Stub(base, &(lpspiState->fifoSize));

    /* Configure bus for this device. If NULL is passed, we assume the caller has
     * preconfigured the bus and doesn't wish to re-configure it again for this transfer.
     * Do nothing for calculatedBaudRate. If the user wants to know the calculatedBaudRate
     * then they can call this function separately.
     */
    errorCode = LPSPI_DRV_MasterConfigureBus_Stub(instance, spiConfig, NULL);
    if (errorCode != STATUS_SUCCESS)
    {
        return errorCode;
    }
    /* When TX is null the value sent on the bus will be 0 */
    lpspiState->dummy = 0;
    /* Initialize the semaphore */
   // errorCode = OSIF_SemaCreate(&(lpspiState->lpspiSemaphore), 0);
   //  DEV_ASSERT(errorCode == STATUS_SUCCESS);
    /* Enable the interrupt */
    INT_SYS_EnableIRQ(g_lpspiIrqId[instance]);
    /* Finally, enable LPSPI */
    LPSPI_Enable(base);
    baudRate = LPSPI_SetBaudRate(base, spiConfig->bitsPerSec, spiConfig->lpspiSrcClk, &tcrPrescaleValue);

    lpspi_tx_cmd_config_t txCmdCfg =
    {
        .frameSize = spiConfig->bitcount,  //lpspiState->bitsPerFrame,
        .width = LPSPI_SINGLE_BIT_XFER,
        .txMask = false,
        .rxMask = false,
        .contCmd = false,
        .contTransfer = spiConfig->isPcsContinuous,
        .byteSwap = false,
        .lsbFirst = spiConfig->lsbFirst,
        .whichPcs = spiConfig->whichPcs,
        .preDiv = tcrPrescaleValue,
        .clkPhase = spiConfig->clkPhase,
        .clkPolarity = spiConfig->clkPolarity
    };
    LPSPI_SetTxCommandReg(base, &txCmdCfg);
    return errorCode;
}
error_t spiSetMode(uint_t mode)
{

   return ERROR_NOT_IMPLEMENTED;

}

error_t spiSetBitrate(uint_t bitrate)
{
   return ERROR_NOT_IMPLEMENTED;

}
   #define usleep(delay) {volatile uint32_t n = delay * 4; while(n > 0) n--;}
   #define sleep(delay)  {volatile uint32_t n = delay * 4000; while(n > 0) n--;}

void spiAssertCs(void)
{
	//PINS_DRV_SetPins(PTB, (0u  <<  PIN_5));
	PINS_DRV_WritePin(PTB, 5, 0);
	//CS hold time
   	usleep(1);

}

void spiDeassertCs(void)
{
	//CS hold time
   	usleep(1);
//	PINS_DRV_SetPins(PTB, (1u  <<  PIN_5));
	PINS_DRV_WritePin(PTB, 5, 1);

	//CS hold time
   	usleep(1);
}

#if 0
typedef enum
{
    LPSPI_TX_DATA_FLAG      = LPSPI_SR_TDF_SHIFT, /*!< TX data flag */
    LPSPI_RX_DATA_FLAG      = LPSPI_SR_RDF_SHIFT, /*!< RX data flag */
    LPSPI_WORD_COMPLETE     = LPSPI_SR_WCF_SHIFT, /*!< Word Complete flag */
    LPSPI_FRAME_COMPLETE    = LPSPI_SR_FCF_SHIFT, /*!< Frame Complete flag */
    LPSPI_TRANSFER_COMPLETE = LPSPI_SR_TCF_SHIFT, /*!< Transfer Complete flag */
    LPSPI_TRANSMIT_ERROR    = LPSPI_SR_TEF_SHIFT, /*!< Transmit Error flag (FIFO underrun) */
    LPSPI_RECEIVE_ERROR     = LPSPI_SR_REF_SHIFT, /*!< Receive Error flag (FIFO overrun) */
    LPSPI_DATA_MATCH        = LPSPI_SR_DMF_SHIFT, /*!< Data Match flag */
    LPSPI_MODULE_BUSY       = LPSPI_SR_MBF_SHIFT, /*!< Module Busy flag */
    LPSPI_ALL_STATUS        = 0x00003F00U         /*!< Used for clearing all w1c status flags */
} lpspi_status_flag_t;

#endif

uint32_t spiTransfer(uint8_t data)
{
	LPSPI_Type *base;
	base = LPSPI0;
	uint32_t rx_data;
  	__IO uint32_t regdata;

// while(LPSPI0->SR & LPSPI_SR_MBF_MASK)>>LPSPI_SR_MBF_SHIFT==1);
// while( (LPSPI_GetStatusFlag(base, LPSPI_MODULE_BUSY)));
// LPSPI0->SR |= LPSPI_SR_TCF_MASK; /* Clear TCF flag 				*/
  
  //LPSPI0->SR |= LPSPI_SR_TDF_MASK; /* Clear TDF flag 				*/
  LPSPI0->TDR = (uint32_t) data;              /* Transmit data 				*/
  delay_(20);

  do {
     regdata =(LPSPI0->SR & LPSPI_MODULE_BUSY) ;
     } while ((regdata) == 1);


  //while((LPSPI0->SR & LPSPI_SR_TDF_MASK)>>LPSPI_SR_TDF_SHIFT==0);
  //LPSPI0->SR |= LPSPI_SR_TDF_MASK; /* Clear TDF flag 				*/

  // LPSPI0->SR |= LPSPI_MODULE_BUSY; /* Clear Module Busy flag 				*/

  rx_data = LPSPI0->RDR;
  return( rx_data);

  }

//**********************************************************************************
// Added for LAN8651_Driver.c to resolve references for the linker

/**
 * @brief Get the actual length of a multi-part buffer
 * @param[in] buffer Pointer to a multi-part buffer
 * @return Actual length in bytes
 **/



size_t netBufferGetLength(const NetBuffer *buffer)
{
   uint_t i;

   //Total length
   size_t length = 0;

   //Loop through data chunks
   for(i = 0; i < buffer->chunkCount; i++)
   {
      length += buffer->chunk[i].length;
   }

   //Return total length
   return length;
}
/**
 * @brief Read data from a multi-part buffer
 * @param[out] dest Pointer to the buffer where to return the data
 * @param[in] src Pointer to a multi-part buffer
 * @param[in] srcOffset Offset from the beginning of the multi-part buffer
 * @param[in] length Number of bytes to copy
 * @return Actual number of bytes copied
 **/
size_t netBufferRead(void *dest, const NetBuffer *src,
   size_t srcOffset, size_t length)
{
   uint_t i;
   uint_t n;
   size_t totalLength;
   uint8_t *p;

   //Total number of bytes copied
   totalLength = 0;

   //Loop through data chunks
   for(i = 0; i < src->chunkCount && totalLength < length; i++)
   {
      //Is there any data to copy from the current chunk?
      if(srcOffset < src->chunk[i].length)
      {
         //Point to the first byte to be read
         p = (uint8_t *) src->chunk[i].address + srcOffset;
         //Compute the number of bytes to copy at a time
         n = MIN(length - totalLength, src->chunk[i].length - srcOffset);

         //Copy data
         memcpy(dest, p, n);

         //Advance write pointer
         dest = (uint8_t *) dest + n;
         //Total number of bytes copied
         totalLength += n;
         //Process the next block from the start
         srcOffset = 0;
      }
      else
      {
         //Skip the current chunk
         srcOffset -= src->chunk[i].length;
      }
   }

   //Return the actual number of bytes copied
   return totalLength;
}

//**
// * @brief Convert a string representation of a MAC address to a binary MAC address
// * @param[in] str NULL-terminated string representing the MAC address
// * @param[out] macAddr Binary representation of the MAC address
// * @return Error code
// **/
#if 0
error_t macStringToAddr(const char_t *str, MacAddr *macAddr)
{
   error_t error;
   int_t i = 0;
   int_t value = -1;

   //Parse input string
   while(1)
   {
      //Hexadecimal digit found?
      if(isxdigit((uint8_t) *str))
      {
         //First digit to be decoded?
         if(value < 0)
            value = 0;

         //Update the value of the current byte
         if(osIsdigit(*str))
         {
            value = (value * 16) + (*str - '0');
         }
         else if(osIsupper(*str))
         {
            value = (value * 16) + (*str - 'A' + 10);
         }
         else
         {
            value = (value * 16) + (*str - 'a' + 10);
         }

         //Check resulting value
         if(value > 0xFF)
         {
            //The conversion failed
            error = ERROR_INVALID_SYNTAX;
            break;
         }
      }
      //Dash or colon separator found?
      else if((*str == '-' || *str == ':') && i < 6)
      {
         //Each separator must be preceded by a valid number
         if(value < 0)
         {
            //The conversion failed
            error = ERROR_INVALID_SYNTAX;
            break;
         }

         //Save the current byte
         macAddr->b[i++] = value;
         //Prepare to decode the next byte
         value = -1;
      }
      //End of string detected?
      else if(*str == '\0' && i == 5)
      {
         //The NULL character must be preceded by a valid number
         if(value < 0)
         {
            //The conversion failed
            error = ERROR_INVALID_SYNTAX;
         }
         else
         {
            //Save the last byte of the MAC address
            macAddr->b[i] = value;
            //The conversion succeeded
            error = NO_ERROR;
         }

         //We are done
         break;
      }
      //Invalid character...
      else
      {
         //The conversion failed
         error = ERROR_INVALID_SYNTAX;
         break;
      }

      //Point to the next character
      str++;
   }

   //Return status code
   return error;
}
#endif

bool TC6_CB_OnSpiTransaction(uint8_t tc6instance, uint8_t *pTx, uint8_t *pRx, uint16_t len, void *pGlobalTag)
{


	LPSPI_DRV_MasterTransferBlocking(INST_LPSPI_1, pTx, pRx, len, 100000U);

}

uint32_t TC6Regs_CB_GetTicksMs(void)

{
	return(g_One_ms_Timer_Tick_counter);

}

void FTM0_Ovf_Reload_IRQHandler(void)
{
    PINS_DRV_TogglePins(PORTD, (1 << 11U));
	PINS_DRV_WritePin(PTD, 11, (pins_level_type_t) (counter & 0x01) );

	counter++;
	g_One_ms_Timer_Tick_counter++;
	if (counter == 1000U)
    {
    //    PINS_DRV_TogglePins(LED_PORT, (1 << LED_PIN));
        counter = 0;


    }
    FTM_DRV_ClearStatusFlags(INST_FLEXTIMER_MC_1, (uint32_t)FTM_TIME_OVER_FLOW_FLAG);
}

void TC6Regs_CB_OnEvent(TC6_t *pInst, TC6Regs_Event_t event, void *pTag)
	{
	    TC6NoIP_t *lw = pTag;
	    bool reinit = false;
	    switch (event) {
	        case TC6Regs_Event_UnknownError:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]UnknownError" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Transmit_Protocol_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Transmit_Protocol_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Transmit_Buffer_Overflow_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Transmit_Buffer_Overflow_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Transmit_Buffer_Underflow_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Transmit_Buffer_Underflow_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Receive_Buffer_Overflow_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Receive_Buffer_Overflow_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Loss_of_Framing_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Loss_of_Framing_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            reinit = true;
	            break;
	        case TC6Regs_Event_Header_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Header_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Reset_Complete:
	           // PRINT(ESC_CLEAR_LINE ESC_GREEN "[%d]Reset_Complete" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_PHY_Interrupt:
	           // PRINT(ESC_CLEAR_LINE ESC_GREEN "[%d]PHY_Interrupt" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Transmit_Timestamp_Capture_Available_A:
	           // PRINT(ESC_CLEAR_LINE ESC_GREEN "[%d]Transmit_Timestamp_Capture_Available_A" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Transmit_Timestamp_Capture_Available_B:
	           // PRINT(ESC_CLEAR_LINE ESC_GREEN "[%d]Transmit_Timestamp_Capture_Available_B" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Transmit_Timestamp_Capture_Available_C:
	           // PRINT(ESC_CLEAR_LINE ESC_GREEN "[%d]Transmit_Timestamp_Capture_Available_C" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Transmit_Frame_Check_Sequence_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Transmit_Frame_Check_Sequence_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Control_Data_Protection_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Control_Data_Protection_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_RX_Non_Recoverable_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]RX_Non_Recoverable_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            reinit = true;
	            break;
	        case TC6Regs_Event_TX_Non_Recoverable_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]TX_Non_Recoverable_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            reinit = true;
	            break;
	        case TC6Regs_Event_FSM_State_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]FSM_State_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_SRAM_ECC_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]SRAM_ECC_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Undervoltage:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Undervoltage" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Internal_Bus_Error:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Internal_Bus_Error" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_TX_Timestamp_Capture_Overflow_A:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]TX_Timestamp_Capture_Overflow_A" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_TX_Timestamp_Capture_Overflow_B:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]TX_Timestamp_Capture_Overflow_B" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_TX_Timestamp_Capture_Overflow_C:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]TX_Timestamp_Capture_Overflow_C" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_TX_Timestamp_Capture_Missed_A:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]TX_Timestamp_Capture_Missed_A" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_TX_Timestamp_Capture_Missed_B:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]TX_Timestamp_Capture_Missed_B" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_TX_Timestamp_Capture_Missed_C:
	           // PRINT(ESC_CLEAR_LINE ESC_RED "[%d]TX_Timestamp_Capture_Missed_C" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_MCLK_GEN_Status:
	           // PRINT(ESC_CLEAR_LINE ESC_YELLOW "[%d]MCLK_GEN_Status" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_gPTP_PA_TS_EG_Status:
	           // PRINT(ESC_CLEAR_LINE ESC_YELLOW "g[%d]PTP_PA_TS_EG_Status" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Extended_Block_Status:
	           // PRINT(ESC_CLEAR_LINE ESC_YELLOW "[%d]Extended_Block_Status" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_SPI_Err_Int:
	           // PRINT(ESC_CLEAR_LINE ESC_YELLOW "[%d]SPI_Err_Int" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_MAC_BMGR_Int:
	           // PRINT(ESC_CLEAR_LINE ESC_YELLOW "[%d]MAC_BMGR_Int" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_MAC_Int:
	           // PRINT(ESC_CLEAR_LINE ESC_YELLOW "[%d]MAC_Int" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_HMX_Int:
	           // PRINT(ESC_CLEAR_LINE ESC_YELLOW "[%d]HMX_Int" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_GINT_Mask:
	           // PRINT(ESC_CLEAR_LINE ESC_YELLOW "[%d]GINT_Mask" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Chip_Error:
	           // PRINT(ESC_RED "[%d]Chip_error! Please contact microchip support for replacement" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	        case TC6Regs_Event_Unsupported_Hardware:
	           // PRINT(ESC_RED "[%d]Unsupported MAC-PHY hardware found" ESC_RESETCOLOR "\r\n", lw->idx);
	            break;
	    }
	    if (reinit) {
	        TC6Regs_Reinit(pInst);
	    }
	}

#if 0
/*!
 * @brief Disable the TEIE interrupts at the end of a transfer.
 * Disable the interrupts and clear the status for transmit/receive errors.
 */
void LPSPI_DRV_DisableTEIEInterrupts(uint32_t instance)
{
    LPSPI_Type *base = g_lpspiBase[instance];

    LPSPI_SetIntMode(base, LPSPI_TRANSMIT_ERROR, false);
    LPSPI_SetIntMode(base, LPSPI_RECEIVE_ERROR, false);
    (void)LPSPI_ClearStatusFlag(base, LPSPI_TRANSMIT_ERROR);
    (void)LPSPI_ClearStatusFlag(base, LPSPI_RECEIVE_ERROR);
}
#endif
void TC6_CB_OnError(TC6_t *pInst, TC6_Error_t err, void *pGlobalTag)
{
    TC6NoIP_t *lw = pGlobalTag;
    bool reinit = false;
    switch (err) {
        case TC6Error_Succeeded:
            //PRINT(ESC_CLEAR_LINE ESC_GREEN "[%d]No error occurred" ESC_RESETCOLOR "\r\n", lw->idx);
            break;
        case TC6Error_NoHardware:
            //PRINT(ESC_CLEAR_LINE ESC_RED "[%d]MISO data implies that there is no MACPHY hardware available" ESC_RESETCOLOR "\r\n", lw->idx);
            reinit = true;
            break;
        case TC6Error_UnexpectedSv:
            //PRINT(ESC_CLEAR_LINE ESC_RED " [%d]Unexpected Start Valid Flag" ESC_RESETCOLOR "\r\n", lw->idx);
            break;
        case TC6Error_UnexpectedDvEv:
            //PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Unexpected Data Valid or End Valid Flag" ESC_RESETCOLOR "\r\n", lw->idx);
            break;
        case TC6Error_BadChecksum:
            //PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Checksum in footer is wrong" ESC_RESETCOLOR "\r\n", lw->idx);
            reinit = true;
            break;
        case TC6Error_UnexpectedCtrl:
            //PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Unexpected control packet received" ESC_RESETCOLOR "\r\n", lw->idx);
            reinit = true;
            break;
        case TC6Error_BadTxData:
            //PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Header Bad Flag received" ESC_RESETCOLOR "\r\n", lw->idx);
            reinit = true;
            break;
        case TC6Error_SyncLost:
            //PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Sync Flag is no longer set" ESC_RESETCOLOR "\r\n", lw->idx);
            reinit = true;
            break;
        case TC6Error_SpiError:
            //PRINT(ESC_CLEAR_LINE ESC_RED "[%d]TC6 SPI Error" ESC_RESETCOLOR "\r\n", lw->idx);
            reinit = true;
            break;
        case TC6Error_ControlTxFail:
            //PRINT(ESC_CLEAR_LINE ESC_RED "[%d]TC6 Control Message Error" ESC_RESETCOLOR "\r\n", lw->idx);
            break;
        default:
            //PRINT(ESC_CLEAR_LINE ESC_RED "[%d]Unknown TC6 error occurred" ESC_RESETCOLOR "\r\n", lw->idx);
            break;
    }
    if (reinit) {
        TC6Regs_Reinit(pInst);
    }
}
void TC6_CB_OnRxEthernetPacket(TC6_t *pInst, bool success, uint16_t len, uint64_t *rxTimestamp, void *pGlobalTag)
{
    TC6NoIP_t *lw = pGlobalTag;
    TC6NoIP_CB_OnEthernetReceive(lw->idx, lw->tc.ethRxBuf, len);
}
#define UDP_PAYLOAD_OFFSET          (42)
#define BOARD_INSTANCES_MAX         (4)
typedef struct
{
    uint32_t packetCntCurrent;
    uint32_t packetCntTotal;
    uint32_t byteCntCurrent;
    uint32_t byteCntTotal;
    uint32_t previousVal;
    uint32_t errors;
} MainStats_t;

typedef struct
{
    MainStats_t stats[BOARD_INSTANCES_MAX];
    uint32_t    nextStat;
    uint32_t    nextBeaconCheck;
    uint32_t    nextLed;
    uint32_t    iperfTx;
    int8_t      idxNoIp;
    bool        button1;
    bool        button2;
    bool        gotBeaconState;
    bool        lastBeaconState;
    bool        txBusy;
    bool        allowTxStress;
} MainLocal_t;

static MainLocal_t m;
void TC6NoIP_CB_OnEthernetReceive(int8_t idx, const uint8_t *pRx, uint16_t len)
{
    if (len >= (UDP_PAYLOAD_OFFSET + 5)) {
        uint16_t i = UDP_PAYLOAD_OFFSET;
        uint8_t idx = pRx[i++];
        if (idx < BOARD_INSTANCES_MAX) {
            uint32_t val = 0;
            uint32_t previous = m.stats[idx].previousVal;
            val |= pRx[i++] << 24;
            val |= pRx[i++] << 16;
            val |= pRx[i++] << 8;
            val |= pRx[i++];

            if (previous) {
                if ((previous + 1) != val) {
                    m.stats[idx].errors++;
                }
            }
            m.stats[idx].previousVal = val;

            m.stats[idx].byteCntCurrent += len;
            m.stats[idx].byteCntTotal += len;
            m.stats[idx].packetCntCurrent++;
            m.stats[idx].packetCntTotal++;
        }
    }
}

void TC6_CB_OnRxEthernetSlice(TC6_t *pInst, const uint8_t *pRx, uint16_t offset, uint16_t len, void *pGlobalTag)
{
    TC6NoIP_t *lw = pGlobalTag;
    if ((offset + len) < sizeof(lw->tc.ethRxBuf)) {
        memcpy(&lw->tc.ethRxBuf[offset], pRx, len);
    }
}

void TC6_CB_OnNeedService(TC6_t *pInst, void *pGlobalTag)
{
}

